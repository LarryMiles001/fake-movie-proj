import axios from "axios";

export default axios.create({
	baseURL: "https://api.themoviedb.org/3/movie",
});

export const SearchApi = axios.create({
	baseURL: "https://api.themoviedb.org/3",
});
